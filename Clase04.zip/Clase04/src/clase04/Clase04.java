/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clase04;

/**
 *
 * @author alumno
 */
public class Clase04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //String en una clase, por l qe va con inicial mayuscula 
        
        String nombre = "marcela";
        
        System.out.println(nombre);
        
        //pasar texto a mayúsculas 
        
        System.out.println(nombre.toUpperCase() );  //acá lo imprimo en mayuscula, mas no estoy modificando la variable
        
        System.out.println(nombre);
        nombre = nombre.toUpperCase(); // acá sí esty modifiando la variable porque le estoy diciendo que de ahora en adelante la variable  escriba en mayúscula 
        System.out.println(nombre);
        
        //Pasar teccto a minuscula
        
        System.out.println(nombre.toLowerCase() );
        System.out.println(nombre);
        nombre = nombre.toLowerCase();
        System.out.println(nombre); 
        
        // Dadas las variabes imprimir por consola la frase 
        // "A Cuesta le cuesta subir la cuesta y en medio de la cuesta, va y se acuesta":
        
        String palabra1 = "cuesta";
        String palabra2 = "subir";
        String palabra3 = "la"; 
        String palabra4 = "a";
        String palabra5 = "e";
        String palabra6 = "l";
        String palabra7 = "v";
        String palabra8 = "s";
        String palabra9 = "n";
        String palabra10 = "d";
        String palabra11 = "y";
        String palabra12 = "medio";
        
        String palabra13 = "," ; 
        String palabra14 = "Cuesta";
        
       
        
        
        System.out.println(palabra4.toUpperCase() + " " + palabra14 + " " + palabra6 + palabra5 + " " + palabra1 + " " +
                palabra2 + " " + palabra3 + " " + palabra1 + " " + palabra11 + " " + palabra5 + palabra9 + " " + palabra12 + " " + palabra10 + 
                palabra5 + " " + palabra3 + " " + palabra1 + palabra13 + " " + palabra7 + palabra4 +
                        " " + palabra11 + " " + palabra8 + palabra5 + " " + palabra4 + palabra1) ;
        
        
        
  
        
        
       
        
        
        
        
        
        
    }
    
}
